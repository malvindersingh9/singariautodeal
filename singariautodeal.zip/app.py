from flask import Flask, render_template, request, redirect, session, send_file
from twilio.rest import Client
import random, os
from weasyprint import HTML

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "secret123")

TWILIO_SID = os.environ.get("TWILIO_ACCOUNT_SID")
TWILIO_TOKEN = os.environ.get("TWILIO_AUTH_TOKEN")
TWILIO_FROM = os.environ.get("TWILIO_FROM")

client = Client(TWILIO_SID, TWILIO_TOKEN)

@app.route('/', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        mobile = request.form['mobile']
        otp = str(random.randint(100000, 999999))
        session['otp'] = otp
        session['mobile'] = mobile
        if TWILIO_SID:
            client.messages.create(
                body=f"Your OTP is {otp}",
                from_=TWILIO_FROM,
                to=f"+91{mobile}"
            )
        return redirect('/verify')
    return render_template('login.html')

@app.route('/verify', methods=['GET','POST'])
def verify():
    if request.method == 'POST':
        if request.form['otp'] == session.get('otp'):
            session['logged'] = True
            return redirect('/dashboard')
    return render_template('verify.html')

@app.route('/dashboard')
def dashboard():
    if not session.get('logged'):
        return redirect('/')
    return render_template('dashboard.html')

@app.route('/invoice', methods=['GET','POST'])
def invoice():
    if request.method == 'POST':
        data = request.form
        html = render_template('invoice.html', data=data)
        pdf_path = '/mnt/data/invoice.pdf'
        HTML(string=html).write_pdf(pdf_path)
        return send_file(pdf_path, as_attachment=True)
    return render_template('invoice.html', data=None)

if __name__ == "__main__":
    app.run()
